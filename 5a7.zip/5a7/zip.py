l1=['santosh','ashok','raj','kumar']
l2=[450,250,360,451]
d={name:(p/500)*100 for name ,p in zip(l1,l2)}
print(d)
