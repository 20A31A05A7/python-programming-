n1=12
n2=-15.26
print('result-',n1*n2)
