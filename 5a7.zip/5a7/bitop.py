n1,n2=map(int,input('enter two number').strip().split())
print(n1&n2)
print(n1|n2)
print(n1^n2)
