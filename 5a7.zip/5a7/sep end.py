print('its','a','good','day')
print('its','a','good','day',end='  ',sep='')
print('its','a','good','day')


