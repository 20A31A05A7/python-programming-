print(chr(3077))

print(chr(3128)+chr(3074)+chr(3108)+chr(3146)+chr(3127)+chr(3149))
