n=(75/2)+((75/2)/2)
print('kumar has;',n)
print('sam has;',((75/2)-(75/4)))
