n=100.0
if isinstance(n,int):
    print("Integer")
if isinstance(n,float):
    print("Float")

print(type(n))
if type(n)==float:
    print("true")
