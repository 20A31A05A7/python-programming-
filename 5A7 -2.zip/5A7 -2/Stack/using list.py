#stack is lifo-Last In First out
stack=[]
def push():
    element=int(input("enter the element"))
    stack.append(element)
    print(*reversed(stack))
def pop_element():
    if not stack:
        print("stack is empty")
    else:
        e=stack.pop()
        print("removed element:",e)
        print(reversed(stack))
while True:
    print('SELECT OPEERATION 1.PUSH 2.POP 3.QUIT')
    choice=int(input())
    if choice==1:
        push()
    elif choice==2:
        pop_element()
    elif choice==3:
        break
    else:
        print('enter the correct opration')
