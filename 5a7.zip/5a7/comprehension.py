'''l=list(element for element in 'Good Morning')
print(l)'''



'''''l=[2**x for x in range(2,10)]
print(l)'''';'

l=[x for x in range(10,1000,100)]
print(l)
