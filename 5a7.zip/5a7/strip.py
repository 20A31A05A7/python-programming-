a=list(map(int,input('enter').strip().split()))
print(a)
a=list(map(str,input('enter').split()))
print(a)
