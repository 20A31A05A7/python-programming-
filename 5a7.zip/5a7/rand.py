import random
for i in range(0,random.randint(0,10)):
    print(i)
