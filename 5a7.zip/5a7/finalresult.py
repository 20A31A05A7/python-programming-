result=(3*36.32)+56.19-10
print("Final Resuli:",result)
