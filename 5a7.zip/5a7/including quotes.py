s='sai""sadsd'
print(s)                    #to include the '" in str use \ or excluse str with ' with in " viseversa
sai="afadf\"fdsfg"
print(sai)
sai="afadf\nfdsfg"
print(sai)
sai="afadf'\n'fdsfg"
print(sai)

