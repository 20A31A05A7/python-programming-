l,b=map(int,input('enter lenght and breadth:').split())
print("Perimeter",2*(l+b))
