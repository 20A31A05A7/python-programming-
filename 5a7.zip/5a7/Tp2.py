n=int(input('Enter Number'))
if n%2==0:
    if n>0:
        print('Given Number Is Even=Positive')
    else:
          print('Given Number Is Even-Negative')
else:
    if n>0:
       print('Given Number Is Odd=Positive')
    else:
         print('Given Number Is Odd-Negative')
        
