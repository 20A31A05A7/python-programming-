l,b=map(int,input('enter lenght and breadth:').split())
print('area',l*b)
