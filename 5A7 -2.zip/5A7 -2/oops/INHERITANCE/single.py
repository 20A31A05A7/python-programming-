''''class parent:
    def display(self):
        print("parent class")
class child(parent):
    def show(self):
        print("child clas")
c=child()
c.display()
c.show()
'''
class A:
    n=30
class B(A):
    def calc(self):
        c=self.n+70
        print(c)
obj=B()
obj.calc()
