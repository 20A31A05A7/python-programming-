
n= int(input('enter the number:'))
def multiplication(a,i):
      st=str(a)+"x"+str(i)+'='+str(a*i)
      return(st)
for i in range(1,21):
    print(multiplication(n,i))
 '''  


n= int(input('enter the number:'))
def multiplication(a,i):
      #st=str(a)+"*"+str(i)+'='+str(a*i)
      return a,'x',i,'=',a*i
for i in range(1,21):
    print(multiplication(n,i))
    
'''
