i=2
while i<=20:
    print(i)
    i+=2
print("\n'")
i=1
while i<=3
0:
    print(i)
    i+=2
