n1,n2=map(int,input("enter numbers").split())
n=n1+n2
n1=n-n1
n2=n-n2
print(n1,n2)

