import calendar
print(dir(calendar))
#print(calendar.calendar(2022))
print(calendar.month(2022,12))
