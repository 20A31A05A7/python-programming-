n=int(input("Enter Number: "))
if n%11==0:
    print(n,"is divisible by 11")
else:
    print(n,"is  not divisible by 11")
