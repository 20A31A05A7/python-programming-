class mom:
    def mdisplay(self):
        print("mom class")
class dad:
    def ddisplay(self):
        print("dad class")
class child(mom,dad):
    def cdisplay(self):
        print("child class")
c=child()
c.cdisplay()
c.mdisplay()
c.ddisplay()
