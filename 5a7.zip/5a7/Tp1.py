n=int(input('Enter Number'))
if n==500:
    print('yes')
else:
    print('No')
