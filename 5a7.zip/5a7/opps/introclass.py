class computer:
    def config(self):
        print('yes')
lenovo=computer()
lenovo.config()


dell=computer()
dell.config()
