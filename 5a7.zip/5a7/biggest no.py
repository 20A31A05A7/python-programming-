n1,n2=map(int,input('Enter Number').split())
if n1>n2:
    print("Biggest Number is : ",n1)
elif n1==n2:
    print("Biggest Number is : ",n1)
else:
    print("Biggest Number is : ",n2)
    
