import queue
l=queue.Queue(3)
l.put(10)
l.put(20)
print(l.get())
print(l.get())
