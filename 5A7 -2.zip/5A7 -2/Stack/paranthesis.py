s=input()
st=[]
balanced=True
for c in s:
    if c in('{','(','['):
        st.append(c)
    elif (c==')'):
        if(len(st) and st.pop() !='('):
            balanced=False
            break
    elif (c=='}'):
        if(len(st) and st.pop() !='{'):
            balanced=False
            break
    elif (c==']'):
        if(len(st) and st.pop() !='['):
            balanced=False
            break
    else:
        balanced=False
        break
if (balanced==False or len(st)):
    print("unbalanced")
else:
    print('balanced')
            
            
